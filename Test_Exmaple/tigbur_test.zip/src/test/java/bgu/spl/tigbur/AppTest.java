package bgu.spl.tigbur;

import static org.junit.Assert.*;


import org.junit.Before;
import org.junit.After;
import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest {

    @Test
    public void testApp()
    {
        assertTrue( "bob",false );
    }
}
